function [flag]= Script_runGrid_ODE(g1_val)
flag = 1;

%% The script below generates the grids that are already saved
load('C:\Users\susanychen\Google Drive\UCSF Graduate Research (El-Samad)\LANS OPTOGENETICS PROJECT\SYC Modeling\20180919_kinMod_paramsearch\lightInput_files_20180924\20180924_idealizedlightInputs.mat',...
    'lightInputs')
orig_lightInputs = lightInputs;
kfact = 1000;
lightInput=[];
lightInput{1} = orig_lightInputs(1).lightInput./kfact; 
lightInput{2} = orig_lightInputs(2).lightInput./kfact;
lightInput{3} = orig_lightInputs(3).lightInput./kfact;
lightInput{4} = orig_lightInputs(4).lightInput./kfact;
lightInput{5} = orig_lightInputs(5).lightInput./kfact;
lightInput{6} = orig_lightInputs(6).lightInput./kfact;
lightInput{7} = orig_lightInputs(7).lightInput./kfact;
lightInput{8} = orig_lightInputs(8).lightInput./kfact;
lightInput{9} = orig_lightInputs(9).lightInput./kfact; 
lightInput{10} = orig_lightInputs(10).lightInput./kfact;
lightInput{11} = orig_lightInputs(11).lightInput./kfact; 
lightInput{12} = orig_lightInputs(12).lightInput./kfact; % rpl
lightInput{13} = orig_lightInputs(13).lightInput./kfact; % tef
lightInput{14} = orig_lightInputs(14).lightInput./kfact;
lightInput{15} = orig_lightInputs(15).lightInput./kfact; 
lightInput{16} = orig_lightInputs(16).lightInput./kfact; % rpl
lightInput{17} = orig_lightInputs(17).lightInput./kfact; % tef
lightInputTimes = [];
lightInputTimes{1} = orig_lightInputs(1).times;
lightInputTimes{2} = orig_lightInputs(1).times;
lightInputTimes{3} = orig_lightInputs(1).times;
lightInputTimes{4} = orig_lightInputs(1).times;
lightInputTimes{5} = orig_lightInputs(1).times;
lightInputTimes{6} = orig_lightInputs(1).times;
lightInputTimes{7} = orig_lightInputs(1).times;
lightInputTimes{8} = orig_lightInputs(1).times;
lightInputTimes{9} = orig_lightInputs(1).times;
lightInputTimes{10} = orig_lightInputs(1).times;
lightInputTimes{11} = orig_lightInputs(1).times;
lightInputTimes{12} = orig_lightInputs(1).times;
lightInputTimes{13} = orig_lightInputs(1).times;
lightInputTimes{14} = orig_lightInputs(1).times;
lightInputTimes{15} = orig_lightInputs(1).times;
lightInputTimes{16} = orig_lightInputs(1).times;
lightInputTimes{17} = orig_lightInputs(1).times;
%%
%% parameters
load('20190616_params_kineticMod_pYPS1_g1pt06_rerunFIG4','paramset')
param10000 = paramset(:,1:9000);

% get region1: kon/koff 
vals = param10000(1,:)./param10000(2,:);
[v,i]=sort(vals);

% g1 = from 0.025 - 10
g1 = g1_val; %0.1; %[0.025, 0.1, 0.5, 1, 5, 10];
% make GRID kd vs slowness of kon & koff
paramset1 = [.1*20; .23*20 ;param10000(3,i(1)); g1; param10000(5:end,i(1))]; 
paramset2 = [.1*20/5; .23*20/5 ;param10000(3,i(1)); g1; param10000(5:end,i(1))]; 
paramset3 = [.1*20/10; .23*20/10 ;param10000(3,i(1)); g1; param10000(5:end,i(1))]; 
paramset4 = [.1*20/20; .23*20/20 ;param10000(3,i(1)); g1; param10000(5:end,i(1))]; 

paramset5 = [.1; .23*20; param10000(3,i(1))*21;g1; param10000(5:end,i(1))];
paramset6 = [.1./5; (.23*20)./5; param10000(3,i(1))*21; g1; param10000(5:end,i(1))];
paramset7 = [.1./10; (.23*20)./10; param10000(3,i(1))*21; g1; param10000(5:end,i(1))];
paramset8 = [.1./20; (.23*20)./20; param10000(3,i(1))*21; g1; param10000(5:end,i(1))];

paramset9 = [.46; 4.6 ;param10000(3,i(1)); g1; param10000(5:end,i(1))]; 
paramset10 = [.46/5; 4.6/5 ;param10000(3,i(1)); g1; param10000(5:end,i(1))]; 
paramset11 = [.46/10; 4.6/10 ;param10000(3,i(1)); g1; param10000(5:end,i(1))]; 
paramset12 = [.46/20; 4.6/20 ;param10000(3,i(1)); g1; param10000(5:end,i(1))]; 

paramset13 = [.23; 4.6 ;param10000(3,i(1)); g1; param10000(5:end,i(1))]; 
paramset14 = [.23/5; 4.6/5 ;param10000(3,i(1)); g1; param10000(5:end,i(1))]; 
paramset15 = [.23/10; 4.6/10 ;param10000(3,i(1)); g1; param10000(5:end,i(1))]; 
paramset16 = [.23/20; 4.6/20 ;param10000(3,i(1)); g1; param10000(5:end,i(1))]; 

paramset17 = [9.2; 4.6 ;param10000(3,i(1)); g1; param10000(5:end,i(1))]; 
paramset18 = [9.2/5; 4.6/5 ;param10000(3,i(1)); g1; param10000(5:end,i(1))]; 
paramset19 = [9.2/10; 4.6/10 ;param10000(3,i(1)); g1; param10000(5:end,i(1))]; 
paramset20 = [9.2/20; 4.6/20 ;param10000(3,i(1)); g1; param10000(5:end,i(1))]; 

% get all parameters
paramset = [paramset17, paramset18, paramset19 ,paramset20, ...
    paramset1, paramset2, paramset3, paramset4, ...
    paramset9, paramset10, paramset11, paramset12, ...
    paramset13,paramset14, paramset15, paramset16, ...
    paramset5, paramset6, paramset7, paramset8];

%%
% RUN through ODE
numParams = size(paramset,2); % number of params looping through
numLight = length(lightInput);
tspan = linspace(0,360,36e1);
% storage
%allsGen=[];
model_valsGen=[];
for mm = 1:numParams
    % display
    display(strcat('current loop: ', num2str(mm)))

    % run ode for gene expression
    % parameters
    M = []; 
    M(1) = paramset(1,mm); % kact
    M(2) = paramset(2,mm); % kinact
    M(3) = paramset(3,mm);% b1
    M(4) = paramset(4,mm);% g1
    M(5) = paramset(5,mm);% b2
    M(6) = paramset(6,mm); % g2
    M(7) = paramset(7,mm); % b0
    
    for nn = 1:numLight
    %%%%%%%%%%%%%%%%%%DUR%%%%%%%%%%%%%%%%%%%%%%%
    % light input (10min)
    A = struct;
    A.times = lightInputTimes{nn};
    A.nucloc = lightInput{nn};
    % run ODE
    alls = [];
    [alls] = run_Ode_ponIntegral(M,A,tspan);
    %[alls] = run_Ode_linear(M,A,tspan);
    allsGen{mm,nn} = alls;
    % compare MODEL and EXP trace
    prot_end = [];
    N = length(allsGen{mm,nn});
    for k = 1:N
        %display(strcat('k=',num2str(k)));
        s = allsGen{mm,nn}{k};
        prot_end(k) = s.prot(end-3); % yaxis
    end
    model_valsGen{mm,nn} = prot_end;
    end

end

model_valsGen = cell2mat(model_valsGen);
save(['20191001_model_valsGen_GRIDg1pt1'],'allsGen');
end
